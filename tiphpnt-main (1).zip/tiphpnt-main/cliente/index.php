<h2>
   <strong><?php echo $_GET['cliente']; ?></strong>, Bem Vindo à sua área de cliente.
</h2>